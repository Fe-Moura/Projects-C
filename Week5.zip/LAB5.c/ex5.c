#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> 

/*DECODAR*/
int main() {
  int Alin = 2, Acol = 2;
  int max_vet;
  printf("Digite o tamanho do vetor:\n");
  
  scanf("%d", &max_vet);

  printf("Matriz A:\n");

  int mA[Alin][Acol];

  for (int i=0; i < Alin; i++) {
    for (int j=0; j < Acol; j++) {
      scanf("%d", &mA[i][j]);
    }
  }

  printf("Mensagem cifrada:\n");

  int vet[max_vet][Acol];

  for (int i=0; i < max_vet; i++) {
    for (int j=0; j < Acol; j++) {
      scanf("%d", &vet[i][j]);
    }
  }


  printf("Mensagem decifrada:\n");
  int cache_math = 0;

  for (int n=0; n < (int)(max_vet * 0.5); n++) {
    for (int i = 0; i < Alin; i++) {
      for (int j = 0; j < Acol; j++) {
        //printf("DEBUG: %d * %d\n", vet[n][j], mA[i][j]);
        cache_math += (mA[i][j] * vet[n][j]);
        //printf("%d res: %d\n", j, cache_math);
        if (j == Acol-1) {
          printf("%c", cache_math);
          cache_math = 0;
        }
      }
    }
  }
}