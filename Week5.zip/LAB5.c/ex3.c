#include <stdio.h>
#include <stdlib.h>

int main(){
int tLinhaA, tColunaA, tLinhaB, tColunaB;
int i,j,x;

printf("Tamanho da matriz A:\n");
scanf("%d", &tLinhaA);
scanf("%d", &tColunaA);
double matrizA[tLinhaA][tColunaA];


printf("Tamanho da matriz B:\n");
scanf("%d", &tLinhaB);
scanf("%d", &tColunaB);
double matrizB[tLinhaB][tColunaB];


if (tColunaA != tLinhaB){
    printf("Dados incorretos.");
}
else{
    printf("Matriz A:\n");
        for (i = 0; i < tLinhaA; i++){
             for (j = 0; j < tColunaA; j++){
                scanf("%lf", &matrizA[i][j]);
            }
        } 

    printf("Matriz B:\n");
        for (i = 0; i < tLinhaB; i++){
            for (j = 0; j < tColunaB; j++){
                scanf("%lf", &matrizB[i][j]);
            } 
        }
    
    double matrizAB[tLinhaA*tColunaB][tLinhaB*tColunaA];

    printf("Matriz AB:\n");
        for (i = 0; i < tLinhaA; i++){
            for (j = 0; j < tColunaB; j++){
                matrizAB[i][j] = 0;
                for (x = 0; x < tColunaA; x++)
                    matrizAB[i][j] += matrizA[i][x]*matrizB[x][j];
                printf(" %3.4lf ", matrizAB[i][j]);
                }
            printf("\n");
            }
        }
    return 0;
}