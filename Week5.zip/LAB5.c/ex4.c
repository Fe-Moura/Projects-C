#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h> 

#define MAX_STR 100
int main() {

  printf("Mensagem:\n");
  char msg[MAX_STR];

  fgets(msg,sizeof(msg),stdin);

  int Alin = 2, Acol = 2;
  int mA[Alin][Acol];

  printf("Matriz A:\n");

  for (int i=0; i < Alin; i++) {
    for (int j=0; j < Acol; j++) {
      scanf("%d", &mA[i][j]);
    }
  }

  int max_strlen = (int)strlen(msg)-1; //-1 = ignorar hex \0 aka NULL
  printf("Tamanho da mensagem: %d\n", max_strlen);

  /*Mathell*/

  /*Criar pares*/
  int count_v = 0;
  int mChar[max_strlen][2];   
  for (int i = 0; i < max_strlen; i++) {
    int par_iter = i % 2; // 0 = impar ; 1 = par
    mChar[count_v][par_iter] = msg[i]; 
    //printf("%d = %c | %d\n", msg[i], msg[i], par_iter);
    if (par_iter == 1) {   
      count_v++;
    }
  }

  printf("Mensagem Cifrada:\n");

  /*Mult A*B matriz*/
  int cache_math = 0;
  for (int n=0; n < count_v; n++) {
    for (int i = 0; i < Alin; i++) {
      for (int j = 0; j < Acol; j++) {
        //printf("(%d) DEBUG: %d * %d\n", n, mChar[n][j], mA[i][j]);
        cache_math += (mA[i][j] * mChar[n][j]);
        if (j == Acol-1) {
          printf("%d\n", cache_math);
          cache_math = 0; //n ligo
        }
      }
    }
  }

}