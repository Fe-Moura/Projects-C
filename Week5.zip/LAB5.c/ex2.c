#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
  int linA,colA;

  printf("Tamanho da matriz A:\n");

  scanf("%d", &linA);
  scanf("%d", &colA);

  printf("Matriz A:\n");

  double vet1[linA][colA];

  for (int i=0; i <linA; i++) {
    for (int j=0; j < colA; j++) {
      scanf("%lf", &vet1[i][j]);
    }
  }
    
  printf("Digite o vetor com %d coordenadas:\n", colA);

  int cords[colA];
  for (int i = 0; i < colA; i++) {
    scanf("%d", &cords[i]);
  }

  printf("Produto de A por v:\n");

  //*matemagica*//

  double cache_math[colA];
  int count_v = 0;

  for (int i=0; i < linA; i++) {
    for (int j=0; j < colA; j++) {
      cache_math[count_v] += vet1[i][j] * cords[j];
      if (j == colA-1) {
        printf("%.4lf\n", cache_math[count_v]);
        count_v++;
      }
    }
  }

}