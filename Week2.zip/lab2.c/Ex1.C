#include <stdio.h>
#include <stdlib.h>

int main(){
    int a,b,menor,maior;
        scanf("%d",&a);
        scanf("%d",&b);

    menor = a;  

    if (b<a){
        menor = b;
        maior = a;
    }

    printf("%d %d", menor,maior);
    
    return 0;
}