#include <stdio.h>
#include <stdlib.h>


int main() {
    int a, b, c;
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);

    if (a > c) {
        int tmp = c;
        c = a;
        a = tmp;
    }
    if (a > b) {
        int tmp = b;
        b = a;
        a = tmp;
    }
    if (b > c) {
        int tmp = c;
        c = b;
        b = tmp;
    }
    

    if (a+b>c){
        printf("S");
    }
    else{
        printf("N");
    }
    


    return 0;
}