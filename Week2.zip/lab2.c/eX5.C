#include <stdio.h>
#include <stdlib.h>

int main(){
  int num,inv;
  scanf("%d",&num);

  if (num>=0){
    if (num%10 == 0){
        num = num/10;    
    }
    while (num!=0) {
        inv=num % 10;  
        printf("%d",inv);
        num = num/10;
    }
  }
    return 0;
}

