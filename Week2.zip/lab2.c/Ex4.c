#include <stdio.h>
#include <stdlib.h>

int main(){
    int num,num1,num2,i,math;
    i = 1;
    scanf("%d",&num);
    scanf("%d",&num1);
    scanf("%d",&num2);


    while(i<num2){
        math = num*i;
        i=i+1;
        if (math>=num1 && math<=num2){
            printf("%d ", math);
        }
    }
}
