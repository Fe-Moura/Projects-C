#include <stdio.h>
#include <stdlib.h>

int main() {
    int a, b, c, d;
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);
    scanf("%d",&d);

    if (a > d) {
        int tmp = d;
        d = a;
        a = tmp;
    }
    if (a > c) {
        int tmp = c;
        c = a;
        a = tmp;
    }
    if (a > b) {
        int tmp = b;
        b = a;
        a = tmp;
    }

    if (b > d) {
        int tmp = d;
        d = b;
        b = tmp;
    }
    if (b > c) {
        int tmp = c;
        c = b;
        b = tmp;
    }
    if (b > a) {
        int tmp = a;
        a = b;
        b = tmp;
    }

    if (c > d) {
        int tmp = d;
        d = c;
        c = tmp;
    }
    if (c > b) {
        int tmp = b;
        b = c;
        c = tmp;
    }
    if (c > a) {
        int tmp = a;
        a = c;
        c = tmp;
    }
    
    printf("%d %d %d %d", c,a,b,d);
}