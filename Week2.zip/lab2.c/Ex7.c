#include <stdio.h>
#include <stdlib.h>


int main() {
    int a, b, fibonacci, i, n;

    a = 0;
    b = 1;
    scanf("%d", &n);

    for(i = 2; i < n; i++) {

        fibonacci = a + b;
        a = b;
        b = fibonacci;

    }
    printf("%d", fibonacci);
}