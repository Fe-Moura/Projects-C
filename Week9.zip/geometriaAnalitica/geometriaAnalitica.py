from math import *
print ('Produto Vetorial - Área: ')
print ('Coordenadas do vetor u: ')

vetorux = float(input('Digite a 1a. coordenada: '))
vetoruy = float(input('Digite a 2a. coordenada: '))
vetoruz = float(input('Digite a 3a. coordenada: '))

print ('Coordenadas do vetor v: ')
vetorvx = float(input('Digite a 1a. coordenada: '))
vetorvy = float(input('Digite a 2a. coordenada: '))
vetorvz = float(input('Digite a 3a. coordenada: '))

math = ((vetoruy*vetorvz)-(vetoruz*vetorvy))-((vetorux*vetorvz)-(vetoruz*vetorvx))+((vetorux*vetorvy)-(vetoruy*vetorvx))

if(math<0):
    math *= -1

print ('A área do paralelogramo formada pelos vetores u e v é: {:.2f}'.format(math))


