from math import *
print ('Linearmente Dependente e Linearmente Independente: ')
print ('Coordenadas do vetor u: ')

vetorux = int(input('Digite a 1a. coordenada: '))
vetoruy = int(input('Digite a 2a. coordenada: '))
vetoruz = int(input('Digite a 3a. coordenada: '))

print ('Coordenadas do vetor v: ')
vetorvx = int(input('Digite a 1a. coordenada: '))
vetorvy = int(input('Digite a 2a. coordenada: '))
vetorvz = int(input('Digite a 3a. coordenada: '))


if (vetorux == 0 and vetorvx == 0 and vetoruy != 0 and vetorvy != 0 and vetoruz != 0 and vetorvz != 0):
    if (vetoruy/vetorvy == vetoruz/vetorvz):
        print("Conjunto Linearmente Dependente")

elif (vetoruy == 0 and vetorvy == 0 and vetorux != 0 and vetorvx != 0) and vetoruz != 0 and vetorvz != 0:
    if (vetorux/vetorvx == vetoruz/vetorvz):
        print("Conjunto Linearmente Dependente")

elif (vetoruz == 0 and vetorvz == 0 and vetorux != 0 and vetorvx != 0 and vetoruy != 0 and vetorvy != 0 ):
    if (vetorux/vetorvx == vetoruy/vetorvy):
        print("Conjunto Linearmente Dependente")

elif (vetorux == 0 and vetoruy == 0 and vetoruz == 0 or vetorvx == 0 and vetorvy == 0 and vetorvz == 0):
    print("Conjunto Linearmente Dependente")

elif (vetorux != 0 and vetoruy != 0 and vetoruz != 0 and vetorvx != 0 and vetorvy != 0 and vetorvz != 0): 
    if(vetorux/vetorvx == vetoruy/vetorvy and vetorux/vetorvx == vetoruz/vetorvz and vetoruy/vetorvy == vetoruz/vetorvz):
        print("Conjunto Linearmente Dependente")
    else:
        print("Conjunto Linearmente Independente")
    
else:
    print("Conjunto Linearmente Independente")


    

