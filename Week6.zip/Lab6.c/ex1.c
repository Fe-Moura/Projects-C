#include <stdio.h>
#include <stdlib.h>


int main(void){

    struct calendario
    {   int dia, ano;
        char mes[12];
    }   data;


    printf("Digite o dia:\n");
    scanf("%d", &data.dia);
    
    //CHAR NÃO PRECISA DO "&"!!!!!!
    printf("Escreva o mes:\n");
    scanf("%s", data.mes);
    
    printf("Digite o ano:\n");
    scanf("%d", &data.ano);

    printf("Data: %d/%s/%d", data.dia, data.mes, data.ano);
    
    return 0;
}