#include <stdio.h>
#include <stdlib.h>

struct numeros{
    double x,y,z;
}num;

int main(){

    scanf("%lf", &num.x);
    scanf("%lf", &num.y);
    scanf("%lf", &num.z);

    if (num.x > num.z) {
        double tmp = num.z;
        num.z = num.x;
        num.x = tmp;
    }
    if (num.x > num.y) {
        double tmp = num.y;
        num.y = num.x;
        num.x = tmp;
    }
    if (num.y > num.z) {
        double tmp = num.z;
        num.z = num.y;
        num.y = tmp;
    }
    printf("%.4lf\n%.4lf\n%.4lf", num.x, num.y, num.z);

    return 0;
}