#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PI 3.14159265

struct Ponto
{
	double R;
	double I;
};

void leiaPonto(struct Ponto *p)
{
    printf("Digite o valor da parte Real:\n");
	   scanf("%lf", &( (*p).R ) );
    printf("Digite o valor da parte Imaginaria:\n");
	   scanf("%lf", &( (*p).I )  );
   	printf("%.4lf + (%.4lf)i\n", (*p).R, p->I);
}

int menu()
{
    puts("");
    puts("=============");
    puts("1 - Adicao   ");
    puts("2 - Multiplicacao  ");
    puts("3 - Divisao  ");
    puts("4 - Modulo  z1  ");
    puts("5 - Modulo  z2  ");
    puts("6 - Conjugado  z1  ");
    puts("7 - Conjugado  z2  ");
    puts("0 - Sair  ");
    printf("opcao => ");
    int op;
    scanf("%d", &op);

    return op;
}

void imprimePonto( struct Ponto p)
{
	printf("Parte Real: %.4lf \n", p.R  );
	printf("Parte Imaginaria: %.4lf \n", p.I );
	printf("%.4lf + (%.4lf)i\n", p.R, p.I);
}

void soma( struct Ponto p, struct Ponto q )
  {
	struct Ponto ret;
	ret.R = p.R + q.R;
	ret.I = p.I + q.I;
	printf("\nAdicao \n");
	imprimePonto(ret);
	//return ret;
  }

void produto( struct Ponto p, struct Ponto q )
  {
	struct Ponto ret;
    ret.R = p.R*q.R - p.I*q.I;
	ret.I = p.R*q.I + p.I*q.R;
	printf("\nMultiplicacao \n");
	imprimePonto(ret);
	//return ret;
  }

void conjugado( struct Ponto p )
  {
	struct Ponto ret;
	ret.R = (p.R);
	ret.I = -(p.I);
	printf("\nConjugado \n");
	imprimePonto(ret);
  }

double modulo( struct Ponto p )
{
	double mod;
	mod = sqrt((p.R)*(p.R) + (p.I)*(p.I));
	printf("\nModulo \n");
	printf("O modulo de %.4lf + (%.4lf)i eh %.4lf ", p.R, p.I, mod);
	return mod;
}


struct Ponto
  quociente( struct Ponto p, struct Ponto q )
  {
	struct Ponto ret;

	if (q.R == 0 && q.I == 0)
    {
        printf("Dados Incorretos\n");
        return p;
    }

	ret.R = (p.R*q.R + p.I*q.I)/((q.R)*(q.R) + (q.I)*(q.I));
	ret.I = (p.I*q.R - p.R*q.I)/((q.R)*(q.R) + (q.I)*(q.I));
	imprimePonto(ret);
	return ret;
  }

int main(void)
{
	struct Ponto z1;
	struct Ponto z2;

	leiaPonto( &z1 );
	leiaPonto( &z2 );

    int op = menu();
    if(op == 1)
    {
        soma(z1, z2);
    }
    else if(op == 2)
    {
        produto(z1, z2);
    }
    else if(op == 3)
    {
        quociente(z1, z2);
    }
    else if(op == 4)
    {
        modulo(z1);
    }
    else if(op == 5)
    {
        modulo(z2);
    }
    else if(op == 6)
    {
        conjugado(z1);
    }
    else if(op == 7)
    {
        conjugado(z2);
    }

	return 0;