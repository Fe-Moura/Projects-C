#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double *ptr,math1, math2;
    int qtd;

    scanf("%d",&qtd);
    double v[qtd];

    for (int i = 0; i<qtd ; i++){
        ptr = v+i;
        printf("%d numero: ", i+1);
        scanf("%lf", ptr);
        math1 += pow(v[i],2);
        math2 = sqrt(math1);
    }
   

    printf("Modulo = %.4lf", math2);

    return 0;
}