#include <stdio.h>
#include <stdlib.h>

int main(){
    int num;
    double media,soma;

    scanf("%d", &num);
    double valores[num];

    int i = 0;
    while (i < num){
        scanf("%lf", &valores[i]);
        soma += valores[i];
        i++;
    }
    if (i == num){
        media = soma/num;
        printf("%.2lf", media);
    }

    return 0;
}