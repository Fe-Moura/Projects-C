#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double modulo1,modulo2,soma1,soma2,angulo;
    int a,b;
    int i = 0;
    int z = 0;
    

    scanf("%d", &a);
    int vetor1[a];
    while (i<a){
        scanf("%lf", &vetor1[i]);
        soma1 += vetor1[i]*vetor1[i];
        i++;
    }

    scanf("%d", &b);
    int vetor2[b];

    while (z<b){
        scanf("%lf", &vetor2[z]);
        soma2 += vetor2[z]*vetor2[z];
        z++;
    }

    if (i==a && z==b){ 
        modulo1 = sqrt(soma1);
        modulo2 = sqrt(soma2);
        angulo = ((vetor1[i]*vetor2[z])/(modulo1*modulo2));
        printf("Angulo entre os vetores: %.4lf graus", angulo);
    }

    return 0;
}