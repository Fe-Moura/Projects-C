#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int num;
    double modulo,soma;

    scanf("%d", &num);
    double vetor[num];

    int i = 0;
    while (i<num){
        scanf("%lf", &vetor[i]);
        soma += vetor[i]*vetor[i];
        i++;
    }
    if (i == num){
        modulo = sqrt(soma);
        printf("Modulo = %.2lf", modulo);
    }

    return 0;
}