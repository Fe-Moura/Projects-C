#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int main(){
    int n;
    scanf("%d",&n);
    double vetx[n], vety[n], menor, maior,MenorDist, MaiorDist;
    
    for( int i=0; i<n; i++)
    {
        scanf("%lf",&vetx[i]);
    }
    for( int i=0; i<n; i++)
    {
        scanf("%lf",&vety[i]);
    }

    //Puxando o primeiro
    menor=fabs(vetx[0]-vety[0]);
    for(int i=0; i<n;i++)
    {
      for(int j=0; j<n;j++)
      {
        MenorDist= fabs(vetx[i] - vety[j]);
        if(MenorDist < menor)
        { 
          menor=MenorDist;
      }
      }
    }
    maior=fabs(vetx[0]-vety[0]);
    for(int i=0; i < n;i++)
    {
      for(int j=0; j < n;j++)
      {
        MaiorDist= fabs(vetx[i] - vety[j]);
        if(MaiorDist > maior)
        { 
          maior=MaiorDist;
      }
      }
    }

    
    printf("Menor Distancia: %.2lf\n",menor);
    printf("Maior Distancia: %.2lf",maior);
    
}