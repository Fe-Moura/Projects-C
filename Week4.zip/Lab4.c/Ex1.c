#include <stdio.h>
#include <stdlib.h>

int main (){
  int num;
  int maior = 0;
  int posicao = 0;

  scanf("%d", &num);
  double lista[num];

  for (int i=0; i < num;i++) {
    scanf("%lf", &lista[i]);
    if (maior < lista[i]) {
      maior = lista[i];
      posicao = i;
    }
  }
  printf("%d", posicao);

  return 0;
}