#include <stdio.h>
#include <stdlib.h>

int main(){
    int n,num;
    int z = 0;

    scanf("%d",&n);
    int vetor[n];

    for (int i=0; i<n; i++){
        scanf("%d", &vetor[i]);
    }
    printf("Busca: ");
    scanf("%d",&num);

    for (z = 0; z<=num ;z++ ){
        if (vetor[z] == num){
            printf("%d ", z);
            break;
        }
    }

    if (vetor[z] != num){
        printf("-1");
    }

    return 0;
}


