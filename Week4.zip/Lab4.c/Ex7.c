#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double x1,x2,x3;
    double y1,y2,y3;

    scanf("%lf", &x1);
    scanf("%lf", &x2);
    scanf("%lf", &x3);

    scanf("%lf", &y1);
    scanf("%lf", &y2);
    scanf("%lf", &y3);

    double prod1 = (x2*y3)-(x3*y2);
    double prod2 = (x3*y1)-(x1*y3);
    double prod3 = (x1*y2)-(x2*y1);

    printf("Produto Vetorial = (%.2lf, %.2lf, %.2lf)", prod1,prod2,prod3);
    return 0;
}