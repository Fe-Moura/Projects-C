#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define M_PI  3.14159265358979323846

int main(){
    double rad,conv;

    printf("Digite o angulo em radianos: \n");
    scanf("%lf", &rad);
    conv = (rad*(180/M_PI));
    printf("O angulo de %.6lf radianos equivale a %.4lf graus.", rad,conv);

    return 0;
}