#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main (){
  float n, media, soma;
  scanf("%f", &n);
  
  for(int i = 0; i < n; i++){
    int numero;
    scanf("%d", &numero);
    soma = numero + soma;
  }
    media = soma/n;
    printf("Media = %f", media);
}