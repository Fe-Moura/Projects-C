#include<stdio.h>
#include <locale.h>
 
int main() {
    int num, i, resultado = 0;
    
    printf("Digite um numero inteiro e positivo:\n");
    scanf("%d", &num);
    
    for (i = 2; i <= num / 2; i++) {
        if (num % i == 0) {
        resultado++;
        break;
        }
    }
    
    if (resultado == 0)
        printf("Primo");
    else
        printf("Composto");
    
    return 0;
}