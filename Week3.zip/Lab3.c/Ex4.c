#include <stdio.h>
#include <stdlib.h>

int main(int n) {
  int cache = n;
  int count = 0;

  if (cache > 0) {
    while(cache != 0) {
      cache = cache / 10;
      count++;
    }
  } else {
    count = 1;
  }
  return count;
}