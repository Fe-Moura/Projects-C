#include <stdio.h>
#include <math.h>
#include <math.h>

float maiorRaiz (float a, float b, float c) {
  float delta = b * b - 4 * a * c;
  
  if (a == 0 || delta < 0)
    return 0;
  
  float x1 = (-b + sqrt (delta)) / 2*a;
  
  float x2 = (-b - sqrt (delta)) / 2*a;
  
  if(x1>x2)
    return x1;
  else 
    return x2;
}


int main() {
  printf("%.1lf",  maiorRaiz(2,5,3));
}
