#include <stdio.h>
#include <stdlib.h>

    int digitos(int n) {
    int qntd = 0;

    while (n!=0) {
        n = n/10;
        qntd++;
    }

    return qntd;
}

int main() {
    printf("%d", digitos(200));
}


