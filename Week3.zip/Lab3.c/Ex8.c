#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double x1,x2,x3;
    double y1,y2,y3;
    double prod;

    printf("Digite as coordenadas do 1o vetor: \n");
    scanf("%lf%lf%lf", &x1,&x2,&x3);
    printf("Digite as coordenadas do 2o vetor: \n");
    scanf("%lf%lf%lf", &y1,&y2,&y3);

    prod = (x1*y1)+(x2*y2)+(x3*y3);

    printf("Produto Escalar: %.6lf",prod);

    return 0;
}