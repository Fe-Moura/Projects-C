#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    double rad,graus;
    double pi = 3.14159265358979323846;

    printf("Digite o angulo em radianos: \n");
    scanf("%lf", &rad);

    graus = (rad*(180/pi));
    printf("O angulo de %.6lf radianos equivale a %.6lf graus.",rad,graus);

    return 0;
}