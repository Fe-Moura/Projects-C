#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(){
    int x1,y1;
    int x2,y2;
    double raiz;
    int raiz1;

    printf("Digite as coordenadas do 1o. ponto: \n");
    scanf("%d%d", &x1,&y1);
    printf("Digite as coordenadas do 2o. ponto: \n");
    scanf("%d%d", &x2,&y2);
    raiz1 = (((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)));
    raiz = sqrt(raiz1);

    printf("Distancia entre os dois pontos: %.6lf",raiz);

    return 0;
}