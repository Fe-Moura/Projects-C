#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

typedef struct aluno aluno;
struct aluno {
  char nome[30];
  float media;
  int faltas;
};
int main(){
  
  int qtd_alunos;
  float top[qtd_alunos],top_f[qtd_alunos];
  char top_n[qtd_alunos];

  printf("Defina quantos alunos quer: ");
  scanf("%d", &qtd_alunos);

  struct aluno *SalaDeAula = malloc(qtd_alunos * sizeof(aluno));

  for(int i=0; i < qtd_alunos; i++){
    puts("");
    printf("Defina o nome, as faltas e a media de cada aluno %d: ", i+1);
    printf("\nDefina o nome do aluno %d: ", i+1);
    scanf("%s", SalaDeAula[i].nome);
    printf("\nDefina a media do aluno %d: ", i+1); scanf("%f", &SalaDeAula[i].media);
    printf("\nDefina quantidade de faltas do aluno %d: ", i+1); scanf("%d", &SalaDeAula[i].faltas);
    puts("");
  };

  for(int i = 0; i < qtd_alunos; i++){
    for(int j = 0; j < qtd_alunos; j++){
      if(SalaDeAula[i].media > SalaDeAula[j].media){
        top[i] = SalaDeAula[i].media;
        SalaDeAula[i].media= SalaDeAula[j].media;
        SalaDeAula[j].media = top[i];
  
        top_f[i] = SalaDeAula[i].faltas;
        SalaDeAula[i].faltas = SalaDeAula[j].faltas;
        SalaDeAula[j].faltas = top_f[i];
 
        strcpy(top_n, SalaDeAula[i].nome);
        strcpy(SalaDeAula[i].nome, SalaDeAula[j].nome);
        strcpy(SalaDeAula[j].nome, top_n);
      };
    };    
  };

  for(int i = 0; i < qtd_alunos; i++){
    printf("Nome do aluno: %s\n", SalaDeAula[i].nome);
    printf("Média do aluno: %.2f\n", SalaDeAula[i].media);
    printf("Faltas do aluno: %d\n", SalaDeAula[i].faltas);
  };
};