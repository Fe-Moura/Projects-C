#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(){
  int sum = 0, num;

  printf("Defina quantos elementos: ");
  scanf("%d", &num);
  int *vetorx_num;
  vetorx_num = malloc(num * sizeof(int));

  for(int i = 0; i < num; i++){
    printf("Defina a posição: %d? ",i+1);
    scanf("%d",&vetorx_num[i]);
  };

  for (int i = 0; i < num; i++){        
    if (!(vetorx_num[i]%2 == 0)){
      sum += vetorx_num[i];
    }
  }
  printf("\nA soma dos números ímpares é: %d.\n", sum);
}