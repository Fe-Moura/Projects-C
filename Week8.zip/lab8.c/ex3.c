#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main() {
  int qtd_elem;
  printf("Tamanho do vetor: ");
  scanf("%d", &qtd_elem);
  int *vetor_pricipal = malloc(qtd_elem * sizeof(int)); 
  for(int i=0; i < qtd_elem; i++)
  {
    printf("Valor na posicao %d: ",i);
    scanf("%d",&vetor_pricipal[i]);
  }

  printf("\nVetor final: ");
  for (int i = 0; i < qtd_elem; i++){
    printf("%d ", vetor_pricipal[i]);
  };
}