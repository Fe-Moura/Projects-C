#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int j=0;

int escrever(int vetor[],int qtd){
  puts("O conjunto união terá os seguintes elementos{");
  for (int i=0; i<qtd;i++) {
    printf("%d ",vetor[i]);
  }
  printf("\b}");
}

int* uniao(int vetor1[],int elemento1,int vetor2[],int elemento2){
  int *vetor3 = (int*)malloc( elemento1 + elemento2 * sizeof(int));

  for (int i=0;i<elemento1+elemento2;i+=2){
    vetor3[i]=vetor1[j];
    vetor3[i+1]=vetor2[j];
    j++;
  }
  return vetor3;
}

int main() {
  int elemento1,elemento2,elemento3;

  puts("Quantos elementos o 1º conjunto vai ter? ");
  scanf("%d",&elemento1);
  int *vetor1 = (int*)malloc( elemento1 * sizeof(int) );

  puts("Digite a sequência de inteiros: ");
  for (int i=0; i<elemento1; i++){
    scanf("%d",&vetor1[i]);
  }

  puts("Quantos elementos o 2º conjunto vai ter? ");
  scanf("%d",&elemento2);
  int *vetor2 = (int*)malloc( elemento2 * sizeof(int) );

  puts("Digite a sequência de inteiros: ");
  for (int j=0; j<elemento2; j++){
    scanf(" %d",&vetor2[j]);
  }

  int *vetor3 = (int*)malloc( elemento3 * sizeof(int) );
  vetor3 = uniao(vetor1, elemento1, vetor2, elemento2);
  escrever(vetor3,elemento1+elemento2);
}  