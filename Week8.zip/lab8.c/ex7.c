#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(){
  int qtd;

  printf("Quantidade de elementos: ");
  scanf("%d", &qtd);
  int *vetor;
  vetor = malloc(qtd * sizeof(int));

  for(int i=0; i < qtd; i++) {
    printf("%dº elemento? ",i+1);
    scanf("%d",&vetor[i]);
  }

  printf("Conjunto inverso = {");
  for (int i=qtd-1; i >= 0; i--) {
    printf("%d ",vetor[i]);  
  }
  printf("\b}");

  return 0;
}