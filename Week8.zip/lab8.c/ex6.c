#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main(){
int tLinhaA =3, tColunaA =3, tLinhaB=3, tColunaB=3;
int i,j,x;

double *matrizA = malloc(tLinhaA * tColunaA *sizeof(double));
double *matrizB = malloc (tLinhaB * tColunaB * sizeof(double));


if (tColunaA != tLinhaB){
    printf("Dados incorretos.");
}
else{
    printf("Matriz A:\n");
        for (i = 0; i < tLinhaA; i++){
             for (j = 0; j < tColunaA; j++){
                scanf("%lf", &matrizA[i*tColunaA+j]);
            }
        } 

    printf("Matriz B:\n");
        for (i = 0; i < tLinhaB; i++){
            for (j = 0; j < tColunaB; j++){
                scanf("%lf", &matrizB[i*tColunaB+j]);
            } 
        }
    
    double matrizAB[tLinhaA*tColunaB][tLinhaB*tColunaA];

    printf("Matriz AB:\n");
        for (i = 0; i < tLinhaA; i++){
            for (j = 0; j < tColunaB; j++){
                matrizAB[i][j] = 0;
                for (x = 0; x < tColunaA; x++)
                    matrizAB[i][j] += matrizA[i*tColunaA+x]*matrizB[x*tColunaB+j];
                printf(" %3.2lf ", matrizAB[i][j]);
                }
            printf("\n");
            }
        }
    return 0;
}