#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int verificar(int vetor1[], int qtd, int vetor2[], int qtd2, int vetor3[]){

  int contador = 0;
  for (int i=0;i<qtd;i++){
    for (int j=0; j<qtd2;j++){
      if (vetor1[i] == vetor2[j]){
        vetor3[contador] = vetor1[i];
        if (vetor3[contador-1] != vetor1[i]) {
          contador++;
        }
      }
    }
  }  

  puts("A Lista com a Intersecção dos elementos é {");
  for (int i=0;i<contador;i++){
    printf("%d ", vetor3[i]);
  } 
  printf("\b}");
}  

int main() {
  int qtd, qtd2,i,j;

  puts("Quantos elementos tem o 1º conjunto? ");
  scanf("%d",&qtd);
  int *vetor1 = malloc(qtd* sizeof(int));
  puts("Insira os elementos: ");
  for (int i; i<qtd ; i++){
    scanf("%d",&vetor1[i]);
  }

  puts("Quantos elementos tem o 2º conjunto? ");
  scanf("%d",&qtd2);
  int *vetor2 = malloc(qtd2* sizeof(int));
  puts("Insira os elementos: ");
  for (int j; j<qtd2 ; j++){
    scanf("%d",&vetor2[j]);
  }

  int *vetor3 = malloc(qtd+qtd2 * sizeof(int));
  verificar(vetor1, qtd, vetor2, qtd2, vetor3);

  return 0;
}